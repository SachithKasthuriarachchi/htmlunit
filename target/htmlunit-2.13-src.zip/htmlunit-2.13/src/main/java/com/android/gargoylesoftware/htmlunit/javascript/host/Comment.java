/*
 * Copyright (c) 2002-2013 Gargoyle Software Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.gargoylesoftware.htmlunit.javascript.host;

import static com.android.gargoylesoftware.htmlunit.BrowserVersionFeatures.HTML_COMMENT_ELEMENT;
import static com.android.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE;

import com.android.gargoylesoftware.htmlunit.html.DomComment;
import com.android.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser;
import com.android.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.android.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.android.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.android.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

/**
 * A JavaScript object for a Comment.
 *
 * JavaScript: in IE, Comment is Element, but in FF: Comment is CharacterDataImpl.
 *
 * However, in DOM, Comment is CharacterDataImpl.
 *
 * @version $Revision$
 * @author Mirko Friedenhagen
 * @author Ahmed Ashour
 */
@JsxClass(domClasses = DomComment.class)
public final class Comment extends CharacterDataImpl {

    /**
     * Creates an instance. JavaScript objects must have a default constructor.
     */
    public Comment() {
    }

    /**
     * Returns the element ID.
     * @return the ID of this element
     */
    @JsxGetter(@WebBrowser(IE))
    public String getId() {
        return "";
    }

    /**
     * Returns the class defined for this element.
     * @return the class name
     */
    @JsxGetter(value = @WebBrowser(IE), propertyName = "className")
    public Object getClassName_js() {
        return "";
    }

    /**
     * Returns the tag name of this element.
     * @return the tag name
     */
    @JsxGetter(@WebBrowser(IE))
    public Object getTagName() {
        return "!";
    }

    /**
     * Returns the text of this element.
     * @return the text
     */
    @JsxGetter(@WebBrowser(IE))
    public String getText() {
        return "<!--" + getData() + "-->";
    }

    /**
     * Returns the document of this element.
     * @return the document
     */
    @JsxGetter(@WebBrowser(IE))
    public Object getDocument() {
        return getWindow().getDocument_js();
    }

    /**
     * Gets the attribute node for the specified attribute.
     * @param attributeName the name of the attribute to retrieve
     * @return the attribute node for the specified attribute
     */
    @JsxFunction(@WebBrowser(IE))
    public Object getAttributeNode(final String attributeName) {
        return null;
    }

    /**
     * Returns the value of the specified attribute.
     * @param attributeName attribute name
     * @param flags IE-specific flags (see the MSDN documentation for more info)
     * @return the value of the specified attribute, <code>null</code> if the attribute is not defined
     * @see <a href="http://msdn.microsoft.com/en-us/library/ms536429.aspx">MSDN Documentation</a>
     * @see <a href="http://reference.sitepoint.com/javascript/Element/getAttribute">IE Bug Documentation</a>
     */
    @JsxFunction(@WebBrowser(IE))
    public Object getAttribute(final String attributeName, final Integer flags) {
        return null;
    }

    /**
     * Gets the innerText attribute.
     * @return the innerText
     */
    @JsxGetter(@WebBrowser(IE))
    public String getInnerText() {
        return "";
    }

    /**
     * Currently does nothing.
     * @param value the new value for the contents of this node
     */
    @JsxSetter(@WebBrowser(IE))
    public void setInnerText(final String value) {
        // nothing
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getClassName() {
        if (getWindow().getWebWindow() != null
                && getBrowserVersion().hasFeature(HTML_COMMENT_ELEMENT)) {
            return "HTMLCommentElement";
        }
        return super.getClassName();
    }
}
